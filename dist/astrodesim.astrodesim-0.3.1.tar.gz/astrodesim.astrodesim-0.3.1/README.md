# astrodesim
Dust Emission Spectral Index Map
